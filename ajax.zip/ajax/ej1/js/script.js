window.addEventListener('load',()=>{
    document.getElementById('btnTraer').addEventListener('click',traerTexto);

})

function traerTexto(){

    //alert("Hola");
    //Menos en explorer funciona. (Sera nuestra peticion.)

    let xhr = new XMLHttpRequest();
    //Nos interesa el ready state 4. y se lanza cada vez que cambia. Son 5
    xhr.onreadystatechange = ()=>{
        let info = document.getElementById('info');
        // aca va el codigo que maneja la peticion.
        if(xhr.readyState == 4)
        {
            if(xhr.status == 200)
            {
                setTimeout(()=>{
                    info.innerText = xhr.responseText;

                },3000);
                //Asi te va a mostrar el txt
                ///TE lo muestra como html
                //info.innerHTML = "<h1> Esto es un titulo </h1>";
            }
            else{
                console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
            }
        }
        else{
            info.innerHTML = '<img src="./imagenes/spinner.gif" alt="spinner" />';
        }
    }
    ///Abrimos la conexion.
    xhr.open('GET','./documento.txt',true);
    //La enviamos.
    xhr.send();

}
